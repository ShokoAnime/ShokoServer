define(function(require, exports, module) {
"use strict";

exports.snippetText = require("../requirejs/text!./dot.snippets");
exports.scope = "dot";

});
