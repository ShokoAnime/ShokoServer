define(function(require, exports, module) {
"use strict";

exports.snippetText = require("../requirejs/text!./abc.snippets");
exports.scope = "abc";

});
