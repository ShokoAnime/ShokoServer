define(function(require, exports, module) {
"use strict";

exports.snippetText = require("../requirejs/text!./erlang.snippets");
exports.scope = "erlang";

});
