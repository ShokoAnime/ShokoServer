To run MediaInfo, you need JNative
JNative jar may be downloaded from http://jnative.sourceforge.net .

Java 1.4.2 users:
Retroweaver makes it possible to run JNative on Java RE 1.4.2.
Retroweaver can be found at: http://sourceforge.net/projects/retroweaver/